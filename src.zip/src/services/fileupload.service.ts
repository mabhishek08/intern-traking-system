import { HttpClient, HttpEventType, HttpHeaders, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileuploadService {
  private baseUrl = 'http://localhost:1236';

  constructor(private http: HttpClient) { }

  uploadFiles(formData: FormData): Observable<any> {
    const url = `${this.baseUrl}/topic/upload`;
    const req = new HttpRequest('POST', url, formData, {
      reportProgress: true,
      headers: new HttpHeaders(),
      responseType: 'text'
    });
    return this.http.request(req);
    
  }
}
  
  



