import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  readonly baseUrl = environment.apiUrl;
  constructor(private http: HttpClient) {}

  addData(url ='', data = {}) {
   return this.http.post(this.baseUrl + url, data);
  }

  updateData(id: any, url = '', data = {}) {
   return this.http.put(this.baseUrl + `${url}/${3}`, data);
  }

  deleteData(id:string, url = '') {
   return this.http.delete(this.baseUrl + `${url}/${3}`);
  }
  getData(id: any, url = '') {
   return this.http.get(this.baseUrl + `${url}/${2}`);
  }

  getList(url = ''){
    return this.http.get<any>(this.baseUrl + `${url}`);
  }
}
