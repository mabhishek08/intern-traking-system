import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private authService:AuthService) {}

  intercept(request: HttpRequest<any>, next: HttpHandler) {
    // Get the user's role from your authentication service
    const userRole = 'ROLE_ADMIN'; // Assume the user has an ADMIN role
    console.log('User role:', userRole);

    // Modify the request to add the role header
    const authRequest = request.clone({
      headers: request.headers.set('X-User-Role', userRole),

    
    });
    console.log('Modified request:', authRequest);
    return next.handle(authRequest);
  }
}










