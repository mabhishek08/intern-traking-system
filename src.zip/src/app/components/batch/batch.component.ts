import { Component ,OnInit} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonService } from 'src/app/services/common.service';
import { DeleteConfrimationComponent } from 'src/app/shared/components/delete-confrimation/delete-confrimation.component';

@Component({
  selector: 'app-batch',
  templateUrl: './batch.component.html',
  styleUrls: ['./batch.component.scss'],
})
export class BatchComponent implements OnInit {
  batch: any[] = [];
  start = 0;
  end = 5;
  addBatch() {
    this.batch.push({
      action: '',
      code: '',
      name: '',
      isEditable: true,
      isExpanded: true,
      startDate: new Date(),
      program: [],
      topics: [],
      course: [],
    });
  }
  constructor(private dialog: MatDialog,private commonService:CommonService) {}

  ngOnInit(): void {
    this.commonService.getList('batch').subscribe(
      (res) => {
        console.log(res);
        this.batch=res.data
      },
      (err) => {
        console.log(err);
      }
    );
  }
  disbaleEdit(index: number, value = false) {
    this.batch[index].isEditable = value;
    if (this.batch[index].id) {
      this.commonService
        .addData('batch', this.batch[index])
        .subscribe(
          (res) => {
            console.log(res);
          },
          (err) => {
            console.log(err);
          }
        );
    } else {
      this.commonService
        .updateData(
          this.batch[index].id,
          'batch',
          this.batch[index]
        )
        .subscribe(
          (res) => {
            console.log(res);
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }
  deleteBatch(index: number) {
    const dialogRef = this.dialog.open(DeleteConfrimationComponent, {
      data: {
        title: 'Delete Batch',
        message: 'Are you sure that you want to delete batch?',
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        this.batch.splice(index, 1);
       this.commonService
        .deleteData('batch', this.batch[index].id)
        .subscribe(
          (res) => {
            console.log(res);
          },
          (err) => {
            console.log(err);
          }
        );
      }
    });
  }
  disableEditForProgram(index: number, programIndex: number, value = false) {
    this.batch[index].program[programIndex].isEditable = value;
  }

  deleteProgram(index: number, programIndex: number) {
    this.batch[index].program.splice(programIndex, 1);
  }

  exandRow(index: number) {
    this.batch[index].isExpanded = !this.batch[index].isExpanded;
  }

  disableEditForCourse(index: number, courseIndex: number, value = false) {
    this.batch[index].course[courseIndex].isEditable = value;
  }

  deleteCourse(index: number, courseIndex: number) {
    this.batch[index].course.splice(courseIndex, 1);
  }
  page(event: any) {
    this.start = ( event.pageSize + event.pageIndex * event.pageSize)-5;
    this.end = event.pageSize + event.pageIndex * event.pageSize;
  }

  addProgram(index: number) {
    this.batch[index].program.push({
      code: '',
      name: '',
      student: '',
      isEditable: true,
    });
  }
  addCourse(index: number) {
    this.batch[index].course.push({
      code: '',
      name: '',
      teacher: '',
      isEditable: true,
    });
  }
}
